package com.ntgclarity.mandarine.repository;

import com.ntgclarity.mandarine.entity.PcDeliveryType;
import com.ntgclarity.mandarine.service.base.BaseRepository;

public interface DeliveryTypeRepository extends BaseRepository<PcDeliveryType> {

}
