/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntgclarity.mandarine.controller.endpoint;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ntgclarity.mandarine.entity.Attribute;
import com.ntgclarity.mandarine.service.AttributeService;

/**
 *
 * @author Sheko
 */
@CrossOrigin()
@RestController
@RequestMapping(path = "/api/v1/attribute", produces = "application/json")
public class AttributeController {

    @Autowired
    AttributeService attributeService;

    @RequestMapping(path = "/add", method = RequestMethod.POST)
    public void addAttribue(@RequestBody Attribute attribute) {
        attributeService.addAttribute(attribute);
    }

    @RequestMapping(path = "/all", method = RequestMethod.GET)
    public List<Attribute> getAllAttributes() {
        return attributeService.getAllAttributes();
    }

    @RequestMapping(path = "/update", method = RequestMethod.POST)
    public void updateAttribute(@RequestBody Attribute attribute) {
        attributeService.updateAttribute(attribute);
    }

    @RequestMapping(path = "/delete", method = RequestMethod.POST)
    public void deleteAttribute(@RequestBody Attribute attribute) {
        attributeService.deleteAttribute(attribute);
    }
    @RequestMapping(path = "/selectOne", method = RequestMethod.POST)
    public Attribute getOneAttribute(Long id)
    {
        return attributeService.getOneAttribute(id);
    }
}
