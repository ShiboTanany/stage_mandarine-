/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ntgclarity.mandarine.repository;

import com.ntgclarity.mandarine.entity.CancelationReason;
import com.ntgclarity.mandarine.service.base.BaseRepository;

/**
 *
 * @author yasmeen
 */
public interface CancelationReasonRepository extends BaseRepository<CancelationReason>{
    
}
