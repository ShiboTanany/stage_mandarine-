package com.ntgclarity.mandarine.dto;

public class StatsticsDto {
	private int totalOrder;

	private int totalServices;

	private int totalComponent;

	private int totalCategory;

	public int getTotalOrder() {
		return totalOrder;
	}

	public void setTotalOrder(int totalOrder) {
		this.totalOrder = totalOrder;
	}


	public int getTotalServices() {
		return totalServices;
	}

	public void setTotalServices(int totalServices) {
		this.totalServices = totalServices;
	}


	public int getTotalComponent() {
		return totalComponent;
	}

	public void setTotalComponent(int totalComponent) {
		this.totalComponent = totalComponent;
	}


	public int getTotalCategory() {
		return totalCategory;
	}

	public void setTotalCategory(int totalCategory) {
		this.totalCategory = totalCategory;
	}


}
