package com.ntgclarity.mandarine.repository;

import com.ntgclarity.mandarine.entity.Component;

import com.ntgclarity.mandarine.entity.Modifyreason;

import com.ntgclarity.mandarine.service.base.BaseRepository;
public interface ModifyReasonRepository extends BaseRepository<Modifyreason>  {

}
