package com.ntgclarity.mandarine.repository;

import com.ntgclarity.mandarine.entity.Component;

import com.ntgclarity.mandarine.entity.Servicemigration;

import com.ntgclarity.mandarine.service.base.BaseRepository;



public interface ServiceMigrationRepository extends BaseRepository<Servicemigration> {

}