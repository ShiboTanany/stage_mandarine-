package com.ntgclarity.mandarine.repository;

import com.ntgclarity.mandarine.entity.Component;
import com.ntgclarity.mandarine.entity.Contractterms;
import com.ntgclarity.mandarine.service.base.BaseRepository;

public interface ContractTermsRepository  extends BaseRepository<Contractterms> {

}