package com.ntgclarity.mandarine.repository;

import com.ntgclarity.mandarine.entity.EmployeeDiscountCategory;
import com.ntgclarity.mandarine.service.base.BaseRepository;

public interface EmployeeDiscountCategoryRepoistory extends BaseRepository<EmployeeDiscountCategory> {

}
