package com.ntgclarity.mandarine.repository;

import com.ntgclarity.mandarine.entity.ServiceCategory;
import com.ntgclarity.mandarine.service.base.BaseRepository;

public interface ServiceCategoryRepository extends BaseRepository<ServiceCategory> {

}
