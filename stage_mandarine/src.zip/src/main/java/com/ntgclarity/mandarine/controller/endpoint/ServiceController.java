package com.ntgclarity.mandarine.controller.endpoint;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ntgclarity.mandarine.constants.CodesAndMessages;
import com.ntgclarity.mandarine.dto.ServiceDto;
import com.ntgclarity.mandarine.dto.StatusResponse;
import com.ntgclarity.mandarine.entity.Category;
import com.ntgclarity.mandarine.entity.Component;
import com.ntgclarity.mandarine.entity.Service;
import com.ntgclarity.mandarine.exception.ApplicationException;
import com.ntgclarity.mandarine.model.CategoryAddResponse;
import com.ntgclarity.mandarine.model.CategoryListResponse;
import com.ntgclarity.mandarine.model.MessageResponse;
import com.ntgclarity.mandarine.model.ServiceAddResponse;
import com.ntgclarity.mandarine.model.ServiceDeleteResponse;
import com.ntgclarity.mandarine.model.ServiceListResponse;
import com.ntgclarity.mandarine.repository.ServiceRepository;
import com.ntgclarity.mandarine.service.ServiceService;
import com.ntgclarity.mandarine.util.Utils;

@RestController
@RequestMapping(path = "/api/v1/Service", produces = "application/json")
@CrossOrigin
public class ServiceController {

	@Autowired
	ServiceService serviceService;

	private static final Logger log = LoggerFactory.getLogger(ServiceController.class);

	@RequestMapping(path = "/add", method = RequestMethod.POST)
	public ResponseEntity<?> addService(@RequestBody Service service) {

		ServiceAddResponse response = new ServiceAddResponse();

		try {

			// Validation
			if (service.getName().trim().isEmpty() || service.getType().trim().isEmpty())
				throw new ApplicationException("400", "category name and type are required");
			serviceService.addService(service);
			response.setMessageResponseObj(
					new MessageResponse(CodesAndMessages.NO_ERRORS_CODE, CodesAndMessages.NO_ERRORS_MESSAGE));
			response.setServiceDTO(new ServiceDto(service));
			log.info("[NTG_LOG_START] 200 OK, add Service request succeeded [NTG_LOG_END]");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (ApplicationException e) {
			e.printStackTrace();
			log.info("[NTG_LOG_START] 400, add Service request failed with error: ("
					+ Utils.buildErrorMessage(e.getStatus()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.buildErrorMessage(e.getStatus()), HttpStatus.BAD_REQUEST);
		} catch (Exception ex) {
			log.error("[NTG_LOG_START] 500, add Service request failed with error: ("
					+ Utils.internalServerError(ex.getMessage()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.internalServerError(ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@RequestMapping(path = "/delete", method = RequestMethod.POST)
	public ResponseEntity<?> deleteService(@RequestBody Long id) {

		ServiceDeleteResponse response = new ServiceDeleteResponse();
		try {

			// Validation
			Service service = serviceService.getServiceById(id);

			if (service != null) {

				serviceService.delete(id);
				response.setMessageResponseObj(
						new MessageResponse(CodesAndMessages.NO_ERRORS_CODE, CodesAndMessages.NO_ERRORS_MESSAGE));

				log.info("[NTG_LOG_START] 200 OK, add Service request succeeded [NTG_LOG_END]");
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else {
				throw new ApplicationException("400", "service id is not exist");

			}
		} catch (ApplicationException e) {
			e.printStackTrace();
			log.info("[NTG_LOG_START] 400, add Service request failed with error: ("
					+ Utils.buildErrorMessage(e.getStatus()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.buildErrorMessage(e.getStatus()), HttpStatus.BAD_REQUEST);
		} catch (Exception ex) {
			log.error("[NTG_LOG_START] 500, add Service request failed with error: ("
					+ Utils.internalServerError(ex.getMessage()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.internalServerError(ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// serviceService.deleteService(service);
	}

	@RequestMapping(path = "/update", method = RequestMethod.PUT)
	public ResponseEntity<?> updateService(@RequestBody Service service) {
		ServiceAddResponse response = new ServiceAddResponse();

		try {

			// Validation
			if (service.getName().trim().isEmpty() || service.getType().trim().isEmpty())
				throw new ApplicationException("400", "category name and type are required");
			serviceService.update(service.getId(), service);
			response.setMessageResponseObj(
					new MessageResponse(CodesAndMessages.NO_ERRORS_CODE, CodesAndMessages.NO_ERRORS_MESSAGE));
			response.setServiceDTO(new ServiceDto(service));
			log.info("[NTG_LOG_START] 200 OK, add Service request succeeded [NTG_LOG_END]");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (ApplicationException e) {
			e.printStackTrace();
			log.info("[NTG_LOG_START] 400, add Service request failed with error: ("
					+ Utils.buildErrorMessage(e.getStatus()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.buildErrorMessage(e.getStatus()), HttpStatus.BAD_REQUEST);
		} catch (Exception ex) {
			log.error("[NTG_LOG_START] 500, add Service request failed with error: ("
					+ Utils.internalServerError(ex.getMessage()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.internalServerError(ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@RequestMapping(path = "/getAll", method = RequestMethod.GET)
	
	public ResponseEntity<?> getAllService() {

		ServiceListResponse response = new ServiceListResponse();
		try {
			List<Service> services = serviceService.getAllService();
			List<ServiceDto> servicesDTO = new ArrayList<>();
			for (Service service2 : services) {
				servicesDTO.add(new ServiceDto(service2));
			}
			response.setServiceDtos(servicesDTO);

			response.setMessageResponseObj(
					new MessageResponse(CodesAndMessages.NO_ERRORS_CODE, CodesAndMessages.NO_ERRORS_MESSAGE));
			log.info("[NTG_LOG_START] 200 OK, get all Services request succeeded [NTG_LOG_END]");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (ApplicationException e) {
			log.info("[NTG_LOG_START] 400, get all Services request failed with error: ("
					+ Utils.buildErrorMessage(e.getStatus()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.buildErrorMessage(e.getStatus()), HttpStatus.BAD_REQUEST);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("ERROR MESSAGE IS " + ex.getMessage());
			log.error("[NTG_LOG_START] 500, get all Services request failed with error: ("
					+ Utils.internalServerError(ex.getMessage()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.internalServerError(ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@RequestMapping(path = "/service", method = RequestMethod.POST)
	public ResponseEntity<?> getServiceById(@RequestBody Long id) {
		ServiceAddResponse response = new ServiceAddResponse();
		
		try {

			// Validation
			if (id==null)
				throw new ApplicationException("400", "category name and type are required");
			
			Service service=serviceService.getServiceById(id);
			response.setMessageResponseObj(
					new MessageResponse(CodesAndMessages.NO_ERRORS_CODE, CodesAndMessages.NO_ERRORS_MESSAGE));
			response.setServiceDTO(new ServiceDto(service));
			log.info("[NTG_LOG_START] 200 OK, search Service request succeeded [NTG_LOG_END]");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (ApplicationException e) {
			e.printStackTrace();
			log.info("[NTG_LOG_START] 400, search Service request failed with error: ("
					+ Utils.buildErrorMessage(e.getStatus()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.buildErrorMessage(e.getStatus()), HttpStatus.BAD_REQUEST);
		} catch (Exception ex) {
			log.error("[NTG_LOG_START] 500, search Service request failed with error: ("
					+ Utils.internalServerError(ex.getMessage()).getMessage() + ") [NTG_LOG_END]");
			return new ResponseEntity<StatusResponse>(Utils.internalServerError(ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		
	}

}
