package com.ntgclarity.mandarine.entity;

import static com.mysema.query.types.PathMetadataFactory.forVariable;

import com.mysema.query.types.Path;
import com.mysema.query.types.PathMetadata;
import com.mysema.query.types.path.DateTimePath;
import com.mysema.query.types.path.EntityPathBase;
import com.mysema.query.types.path.NumberPath;
import com.mysema.query.types.path.PathInits;
import com.mysema.query.types.path.StringPath;

public class QModifyreason  extends EntityPathBase<Modifyreason> {

    private static final long serialVersionUID = -162257031L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QModifyreason contract = new QModifyreason("Modifyreason");

    public final com.ntgclarity.mandarine.service.base.QBaseEntity _super = new com.ntgclarity.mandarine.service.base.QBaseEntity(this);

    
    //inherited
    public final DateTimePath<java.util.Date> createdAt = _super.createdAt;

    //inherited
    public final StringPath createdBy = _super.createdBy;

    //inherited
    public final NumberPath<Integer> deleted = _super.deleted;

    public final StringPath email = createString("email");

    //inherited
    public final NumberPath<Long> id = _super.id;

    public final StringPath phone = createString("phone");

 

    //inherited
    public final DateTimePath<java.util.Date> updatedAt = _super.updatedAt;

    //inherited
    public final StringPath updatedBy = _super.updatedBy;

    public final StringPath userName = createString("userName");

    public QModifyreason(String variable) {
        this(Modifyreason.class, forVariable(variable), INITS);
    }

    public QModifyreason(Path<? extends Modifyreason> path) {
        this(path.getType(), path.getMetadata(), path.getMetadata().isRoot() ? INITS : PathInits.DEFAULT);
    }

    public QModifyreason(PathMetadata<?> metadata) {
        this(metadata, metadata.isRoot() ? INITS : PathInits.DEFAULT);
    }

    public QModifyreason(PathMetadata<?> metadata, PathInits inits) {
        this(Modifyreason.class, metadata, inits);
    }

    public QModifyreason(Class<? extends Modifyreason> type, PathMetadata<?> metadata, PathInits inits) {
        super(type, metadata, inits);
      //  this.serviceId = inits.isInitialized("serviceId") ? new QContractterms(forProperty("serviceId")) : null;
    }

}